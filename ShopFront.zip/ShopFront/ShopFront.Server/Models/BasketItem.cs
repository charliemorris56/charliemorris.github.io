﻿namespace ShopFront.Models
{
    public class BasketItem
    {
        public int ItemId { get; set; }
        public int Quantity { get; set; }
    }

}
