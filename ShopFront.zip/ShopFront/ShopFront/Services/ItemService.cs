﻿using ShopFront.Data;

namespace ShopFront.Services
{
    public class ItemService
    {
        private List<Item> items;
        private bool isLoading = true;

        public async Task<List<Item>> GetItemsAsync()
        {
            if (items != null)
            {
                return items;
            }

            HttpClient httpClient = new HttpClient();
            string errorMessage;

            try
            {
                var response = await httpClient.GetAsync("https://localhost:7285/api/Items");
                if (response.IsSuccessStatusCode)
                {
                    items = await response.Content.ReadFromJsonAsync<List<Item>>();
                    isLoading = false;
                }
                else
                {
                    errorMessage = $"Error fetching data: {response.ReasonPhrase}";
                }
            }
            catch (HttpRequestException e)
            {
                errorMessage = $"Request error: {e.Message}";
            }
            catch (Exception e)
            {
                errorMessage = $"Unexpected error: {e.Message}";
            }

            return items;
        }

        public async Task<bool> IsLoadingAsync() => isLoading;

    }
}
