﻿using Microsoft.AspNetCore.Mvc;
using ShopFront.Models;

namespace ShopFront.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsController : ControllerBase
    {
        private readonly JsonFileService _jsonFileService;

        public ItemsController(JsonFileService jsonFileService)
        {
            _jsonFileService = jsonFileService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Item>>> GetItems()
        {
            var items = await _jsonFileService.GetItemsAsync();
            return Ok(items);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateItem(int id, Item updatedItem)
        {
            var items = await _jsonFileService.GetItemsAsync();
            var item = items.Find(i => i.Id == id);
            if (item == null) return NotFound();

            item.Name = updatedItem.Name;
            item.Price = updatedItem.Price;
            item.StockCount = updatedItem.StockCount;

            await _jsonFileService.SaveItemsAsync(items);
            return NoContent();
        }
    }
}
