﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Collections.Concurrent;
using System.Threading;

namespace Server
{
    class Server
    {
        private ConcurrentBag<Client> m_ClientBag;
        private TcpListener tcpListener;

        public Server(string ipAddress, int port)
        {
            tcpListener = new TcpListener(IPAddress.Parse(ipAddress), port);
        }
        public void Start()
        {
            m_ClientBag = new ConcurrentBag<Client>();
            tcpListener.Start();
            while (true)
            {
                Socket socket = tcpListener.AcceptSocket();
                Client m_Client = new Client(socket);
                m_ClientBag.Add(m_Client);
                Thread thread = new Thread(() => { ClientMethod(m_Client); });
                thread.Start();
            }
        }
        public void Stop()
        {
            tcpListener.Stop();
        }

        private void ClientMethod(Client client)
        {
            try
            {
                string receivedMessage;                
                client.Send("You have connected to the server");

                while ((receivedMessage = client.Read()) != null)
                {
                    Console.WriteLine("Message Recived " + receivedMessage);
                    string serverResponse = GetReturnMessage(receivedMessage);
                    client.Send(serverResponse);
                    if (receivedMessage == "end")
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
            finally
            {
                m_ClientBag.TryTake(out client);
                client.Close();
            }
        }
        private string GetReturnMessage(string code)
        {
            if (code == "hi")
                return "hello";

            return code;
        }
    }
}