﻿using ShopFront.Data;

namespace ShopFront.Services
{
    public class BasketService
    {
        private List<BasketItem> basketItems = new List<BasketItem>();

        public IReadOnlyList<BasketItem> BasketItems => basketItems;

        public void AddToBasket(Item item)
        {
            var basketItem = basketItems.Find(b => b.ItemId == item.Id);
            if (basketItem == null)
            {
                basketItems.Add(new BasketItem { ItemId = item.Id, Quantity = 1, Item = item });
            }
            else
            {
                basketItem.Quantity++;
            }

            item.StockCount--;
        }

        public void RemoveOneFromBasket(Item item)
        {
            var basketItem = basketItems.Find(b => b.ItemId == item.Id);
            if (basketItem != null)
            {
                basketItem.Quantity--;
                item.StockCount++;

                if (basketItem.Quantity == 0)
                {
                    RemoveAllFromBasket(item);
                }
            }
        }

        public void RemoveAllFromBasket(Item item)
        {
            var basketItem = basketItems.Find(b => b.ItemId == item.Id);
            if (basketItem != null)
            {
                item.StockCount += basketItem.Quantity;
                basketItems.Remove(basketItem);
            }
        }

        public void ClearBasket()
        {
            basketItems.Clear();
        }
    }
}
