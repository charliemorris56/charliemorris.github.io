﻿using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using ShopFront.Models;

public class JsonFileService
{
    private readonly string _itemsFilePath;
    private readonly string _ordersFilePath;

    public JsonFileService()
    {
        _itemsFilePath = "Data\\items.json";
        _ordersFilePath = "Data\\orders.json";
    }

    public async Task<List<Item>> GetItemsAsync()
    {
        using var stream = new FileStream(_itemsFilePath, FileMode.Open, FileAccess.Read);
        return await JsonSerializer.DeserializeAsync<List<Item>>(stream);
    }

    public async Task SaveItemsAsync(List<Item> items)
    {
        using var stream = new FileStream(_itemsFilePath, FileMode.Create, FileAccess.Write);
        await JsonSerializer.SerializeAsync(stream, items);
    }

    public async Task<List<Order>> GetOrdersAsync()
    {
        using var stream = new FileStream(_ordersFilePath, FileMode.Open, FileAccess.Read);
        return await JsonSerializer.DeserializeAsync<List<Order>>(stream);
    }

    public async Task SaveOrdersAsync(List<Order> orders)
    {
        using var stream = new FileStream(_ordersFilePath, FileMode.Create, FileAccess.Write);
        await JsonSerializer.SerializeAsync(stream, orders);
    }
}
