﻿namespace ShopFront.Models
{
    public class Order
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string CardNumber { get; set; }
        public string CVV { get; set; }
        public string ExpirationDate { get; set; }
        public IReadOnlyList<BasketItem> Items { get; set; }
    }
}
