﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Client
{
    public class Client
    {
        private TcpClient tcpClient;
        private NetworkStream stream;
        private StreamWriter writer;
        private StreamReader reader;
        private ClientForm clientForm;

        public Client() 
        {
            tcpClient = new TcpClient();
        }
        public bool Connect(string ipAddress, int port)
        {
            try
            {
                tcpClient.Connect(ipAddress, port);
                stream = tcpClient.GetStream();
                writer = new StreamWriter(stream, Encoding.UTF8);
                reader = new StreamReader(stream, Encoding.UTF8);
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
                return false;
            }
        }
        public void Run() 
        {
            clientForm = new ClientForm(this);
            clientForm.ShowDialog();
            Thread thread = new Thread(() => { ProcessServerResponse(); });
            thread.Start();
        }
        public void SendMessage(string message)
        {
            writer.WriteLine(message);
            writer.Flush();
            ProcessServerResponse();
        }
        
        private void ProcessServerResponse()
        {
            //Console.WriteLine("Server says: " + reader.ReadLine());
            //Console.WriteLine();
            clientForm.UpdateChatWindow("Server says: " + reader.ReadLine());
        }
    }
}