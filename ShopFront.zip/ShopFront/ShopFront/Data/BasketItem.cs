﻿namespace ShopFront.Data
{
    public class BasketItem
    {
        public int ItemId { get; set; }
        public int Quantity { get; set; }
        public Item Item { get; set; }
    }

}
