﻿using Microsoft.AspNetCore.Mvc;
using ShopFront.Models;

namespace ShopFront.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly JsonFileService _jsonFileService;

        public OrdersController(JsonFileService jsonFileService)
        {
            _jsonFileService = jsonFileService;
        }

        [HttpPost]
        public async Task<ActionResult<Order>> CreateOrder(Order order)
        {
            var items = await _jsonFileService.GetItemsAsync();
            foreach (var basketItem in order.Items)
            {
                var item = items.Find(i => i.Id == basketItem.ItemId);
                if (item == null || item.StockCount < basketItem.Quantity)
                    return BadRequest("Not enough stock");

                item.StockCount -= basketItem.Quantity;
            }

            var orders = await _jsonFileService.GetOrdersAsync();
            order.Id = orders.Count + 1;
            orders.Add(order);

            await _jsonFileService.SaveOrdersAsync(orders);
            await _jsonFileService.SaveItemsAsync(items);

            return CreatedAtAction(nameof(CreateOrder), new { id = order.Id }, order);
        }
    }
}
